WordWeb version 8.x for Windows Vista, Windows 7, 8 and 10+

Internet: http://wordweb.info

WordWeb is a powerful thesaurus/dictionary for Windows.

LICENCE

Please see http://wordweb.info/free/licence5.html

REDISTRIBUTION

The WordWeb installation may be freely distributed without royalty as long as it
is distributed in the form of the original self-extracting EXE file, which may be
further zipped for some distribution purposes. You may not modify any of the files,
nor may any of the files be distributed separately.

COPYRIGHT

WordWeb is copyright � Antony Lewis 2015. All rights reserved.

WordNet 3.0 Copyright 2006 by Princeton University.  All rights reseved.

THIS SOFTWARE AND DATABASE IS PROVIDED "AS IS" AND PRINCETON UNIVERSITY MAKES
NO REPRESENTATIONS OR WARRANTIES, EXPRESS OR IMPLIED. BY WAY OF EXAMPLE, BUT
NOT LIMITATION, PRINCETON UNIVERSITY MAKES NO REPRESENTATIONS OR WARRANTIES OF
MERCHANTABILITY OR FITNESS FOR ANY PARTICULAR PURPOSE OR THAT THE USE OF THE
LICENSED SOFTWARE, DATABASE OR DOCUMENTATION WILL NOT INFRINGE ANY THIRD PARTY
PATENTS, COPYRIGHTS, TRADEMARKS OR OTHER RIGHTS.

Tesseract OCR originally under Apache 2.0 Licence,
see http://www.apache.org/licenses/LICENSE-2.0
