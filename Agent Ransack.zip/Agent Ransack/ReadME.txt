Agent Ransack Version 2017
Copyright (C) 2017 Mythicsoft Ltd. All rights reserved.

** Introduction **

Welcome to Agent Ransack the 'lite' version of FileLocator Pro.

Agent Ransack is a tool for navigating and understanding data, fast and efficiently.

Agent Ransack provides compelling advantages over similar search tools:
- Regular expressions that allow complex rule based searches.
- Immediate contents results view.
- Various wizards to help the user through the searching process.

Agent Ransack can be used as a replacement or a companion to the standard Windows Search. Agent Ransack provides both a basic interface and a more advanced interface (the default) for the 'Expert user'. Both interfaces provide Wizards to walk the user through the searching process.

Users familiar with the UNIX GREP command will appreciate the ability to search the contents of files using regular expressions and be able to view found contents without having to open the files.

** FileLocator Pro **

For additional search features please try FileLocator Pro, which includes many more features including:
- Text viewer for analysing hits in the context of the file
- Optional indexing and caching
- Keyword reporting and analysis
- Compressed archive searching, such as ZIP, RAR etc.
- Outlook PST/OST searching
- and much more:
http://mythicsoft.com/agentransack/features

** Use and distribution information **

Agent Ransack is a free product but if you use it in a commercial environment you must register (free or paid) it before the expiration of the trial period. You may distribute the complete Agent Ransack installation files provided files are not removed or modified and provided that you do not charge for the distribution. Please read the license agreement for more information.

** Requirements **

Agent Ransack has been tested on Windows Vista/2008/7/8/2012/10 and will need approximately 80MB of disk space to install.

** Other information **

Please see the Credits.txt for information on people/organizations who contributed directly or indirectly to this product.
